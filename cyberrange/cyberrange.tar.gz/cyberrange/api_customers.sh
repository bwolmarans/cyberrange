#!/bin/sh
#echo http://badstore-origin.cudathon.com |cut -d: -f 2 | cut -d/ -f 3
echo $1
x=$1
y=$1
protocol=`echo $x |cut -d{ -f 1`
target=`echo $y |cut -d{ -f 2 | cut -d{ -f 3`
echo $protocol
echo $target
echo "-----------------------------------------"

