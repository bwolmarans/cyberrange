var AWS = require('aws-sdk');
//AWS.config.update({region: 'us-east-1'});
console.log(process.env.AWS_ACCESS_KEY_ID);
console.log(process.env.AWS_SECRET_ACCESS_KEY);
// NOTE: Have to run sudo to get node to run ports less than 1024, then have to run sudo with dash capital E to get centos users environment variables so sudo -E node app.js 
const awsconfig = {
    apiVersion: "2010-12-01",
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    accessSecretKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: "us-east-1"
}
AWS.config.update(awsconfig);
//<- If you want send something to your bucket, you need take off the region settings, because the S3 are global. 

// Create EC2 service object
// var ec2 = new AWS.EC2({apiVersion: '2016-11-15'});


app.get('/start_backend', function (req, res) {
    var params = {
        DryRun: false,
        Filters: [
        {
            Name: 'tag:' + 'dartboard',
            Values: [
                'badstore'
            ]
        }
        ]
    };
    globalres = res;
    ec2_start_stop_wrapper('start', params);
    //res.writeHead(204);
    //res.end();
});
