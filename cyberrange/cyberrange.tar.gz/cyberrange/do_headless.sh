#!/bin/bash
for i in {1..1}
do
  python headless-badstore-cred-spray.py ${1}
done
