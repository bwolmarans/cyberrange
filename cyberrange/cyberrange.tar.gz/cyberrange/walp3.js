var express = require('express');
var app = express();
var https = require('https');

var server = app.listen(3000, function () {
    console.log('Node server is running..');
});
