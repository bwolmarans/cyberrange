function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function demo() {
  console.log('Wait 5 sec');
  await sleep(5000);

  // Sleep in loop
  for (let i = 0; i < 5; i++) {
    console.log('waiting 2 seconds');
    await sleep(2000);
  }
}

demo();
